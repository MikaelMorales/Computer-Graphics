You can find the readme file on how to run the project inside repo/.

The link to the video is inside the Final report pdf but you can also go directly from there: https://youtu.be/vbTUd-wTCmk
(Sorry but the video was 1.1GB, so we couldn't put it on moodle)

The GitHub repository: https://github.com/cparzy/Computer-Graphics-Project.git